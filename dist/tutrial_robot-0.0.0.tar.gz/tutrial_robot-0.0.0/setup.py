from setuptools import setup

setup(
    name='tutrial_robot',
    version='',
    packages=['tutrial_robot'],
    url='',
    license='free',
    author='daisuke',
    author_email='',
    description='robotapp'
)
