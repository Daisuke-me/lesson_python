from setuptools import setup

setup(
    name='tutrial_robot',
    version='',
    packages=[''],
    url='',
    license='Free',
    author='daisuke',
    author_email='',
    description=''
)
